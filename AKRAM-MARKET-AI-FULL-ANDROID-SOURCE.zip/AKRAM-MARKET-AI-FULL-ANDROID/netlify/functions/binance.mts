const ALLOWED = new Set(["time", "klines", "bookTicker"]);
const SYMBOLS = new Set(["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT"]);
const INTERVALS = new Set(["1m", "3m", "5m"]);

export default async (req: Request) => {
  if (req.method !== "GET") return new Response("Method not allowed", { status: 405 });
  const u = new URL(req.url);
  const endpoint = u.searchParams.get("endpoint") || "";
  if (!ALLOWED.has(endpoint)) return new Response("Unsupported endpoint", { status: 400 });
  let target = "https://api.binance.com/api/v3/time";
  if (endpoint === "klines") {
    const symbol = (u.searchParams.get("symbol") || "").toUpperCase();
    const interval = u.searchParams.get("interval") || "";
    const limit = Math.min(240, Math.max(40, Number(u.searchParams.get("limit") || 120)));
    if (!SYMBOLS.has(symbol) || !INTERVALS.has(interval)) return new Response("Invalid market request", { status: 400 });
    target = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
  } else if (endpoint === "bookTicker") {
    const symbol = (u.searchParams.get("symbol") || "").toUpperCase();
    if (!SYMBOLS.has(symbol)) return new Response("Invalid symbol", { status: 400 });
    target = `https://api.binance.com/api/v3/ticker/bookTicker?symbol=${symbol}`;
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 7000);
  try {
    const r = await fetch(target, { signal: controller.signal, headers: { Accept: "application/json" } });
    const body = await r.text();
    return new Response(body, { status: r.status, headers: { "content-type": r.headers.get("content-type") || "application/json", "cache-control": "no-store" } });
  } catch {
    return new Response(JSON.stringify({ error: "upstream_unavailable" }), { status: 502, headers: { "content-type": "application/json" } });
  } finally { clearTimeout(timeout); }
};

export const config = { path: "/api/binance" };
