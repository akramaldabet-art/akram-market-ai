# AKRAM MARKET AI — Full Android Source Handoff

## Purpose
A conservative market-analysis app for PAPER / RESEARCH ONLY. It does not place orders, hold credentials, connect brokerage accounts, or promise profitability.

## User-facing scope
Minimal screen only: Platform, Result, Asset, Time, Entry, Confidence, Data. Results are PAPER BUY, PAPER SELL, WAIT, or NO TRADE.

## Venue policy
Binance is the first live public-data venue. IQ Option and ExpertOption are intentionally fail-closed: DATA UNAVAILABLE / NO TRADE until a verified venue-specific integration is implemented. Never substitute Binance data for another venue.

## Markets / timeframes
Binance: BTCUSDT, ETHUSDT, SOLUSDT, BNBUSDT. Timeframes: 1m, 3m, 5m, 10m. 10m is assembled from consecutive 5m candles.

## Analysis currently implemented
Closed-candle filtering; duplicate/order/gap validation; server-time and latency checks; bid/ask validation; spread gate; EMA 9/21 trend; RSI 14; ATR 14; short momentum; relative volume confirmation; confidence gating; conservative configurable transaction-cost hurdle; signal expiry; 15-second refresh; stale-request sequencing; fail-closed errors.

## Financial assumptions
The embedded prototype uses configurable planning assumptions, not a claim about a user's actual Binance tier: 20 bps round-trip fee allowance + live spread + 4 bps round-trip slippage allowance + 5 bps latency buffer. These must be reviewed for the actual product/account before relying on cost estimates.

## Android build
Prerequisites: Node >=22, Java 21, Android Studio/SDK, platform/target SDK compatible with the selected Capacitor Android release.

1. `npm install`
2. `npm run android:add`
3. `npm run android:sync`
4. `npm run android:open`
5. Build a debug APK in Android Studio, or `npm run android:debug` once Android SDK is configured.

Expected debug output: `android/app/build/outputs/apk/debug/app-debug.apk`.

For a signed release, create/secure your own signing key outside source control and configure Android release signing. Never put a keystore or passwords in this ZIP.

## Netlify optional proxy
`netlify/functions/binance.mts` is an allowlisted public-data proxy. It exposes only Binance server time, klines and bookTicker for the supported symbols/intervals. It contains no secret and no trading endpoint. The current `www/index.html` uses direct Binance public endpoints; a production build may route through this proxy if WebView/network/CORS behavior requires it.

## Security / privacy
No login, no API keys, no wallet, no trading permission, no camera/microphone/location requirement, no analytics SDK, and no personal-data collection are required by this source. HTTPS only is intended. Keep cleartext traffic disabled in the native Android project.

## Production hardening checklist
- Verify exact Capacitor/Android/Gradle/AGP compatibility against current official docs before release.
- Pin and audit dependency lockfile after `npm install`.
- Generate native Android project and confirm min/target/compile SDK values.
- Keep `android:usesCleartextTraffic=false` and INTERNET permission only unless a new feature truly requires more.
- Test cold start, background/resume, network loss, 429/rate limits, slow network, clock skew, stale quotes, missing candles, duplicate candles, malformed payloads, and signal expiry.
- Replace hard-coded price decimals with exchange tick-size metadata before broadening assets.
- Fetch/validate exchange metadata if more symbols are added.
- Keep round-trip cost assumptions explicit/configurable.
- Do not enable IQ Option or ExpertOption until their own verified data feed is implemented and tested.
- Never add order-placement endpoints unless the product scope is deliberately changed away from paper/research-only.

## Important limitations
A signal is an analytical output, not a prediction or guarantee. Public market data can be delayed/unavailable. Mobile network latency, exchange maintenance, rate limiting, malformed data, and device clock errors can force NO TRADE. Conservative fail-closed behavior is intentional.
