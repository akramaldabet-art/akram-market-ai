# Engine Plan / Information Coverage

Data quality gate: enough closed candles; numeric/OHLC sanity; chronological order; duplicate detection; exact timeframe continuity; server/device clock sanity; request RTT; closed-candle freshness; quote validity; bid <= ask; spread ceiling.

Signal inputs: EMA 9/21, RSI 14, ATR 14, 4-candle momentum, 20-candle relative volume, live bid/ask. Direction requires multi-factor agreement. Weak/ambiguous evidence => WAIT. Bad/stale/missing data or excessive cost => NO TRADE.

Cost gate: live spread plus configurable round-trip fee, slippage and latency allowances. Expected move must clear estimated friction. Assumptions are deliberately conservative and must not be represented as exact current fees.

Lifecycle: analyze on start; optional refresh every 15 s; re-analyze on platform/asset/timeframe change and foreground resume; sequence IDs prevent older responses overwriting newer state; paper signal expires at/near current candle boundary.

Future verified-data expansion candidates: exchangeInfo/tick-size precision; weighted quote freshness; order-book depth/imbalance; realized volatility; session/regime filters; multi-timeframe agreement; abnormal-volume filters; maintenance/status checks. Add only if sourced/tested and keep UI minimal.
